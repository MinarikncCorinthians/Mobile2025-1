import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput } from 'react-native';

const App = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleButtonPress = (value) => {
    // Evitar múltiplos operadores consecutivos
    if (['+', '-', '*', '/'].includes(value) && ['+', '-', '*', '/'].includes(input.slice(-1))) {
      return;
    }
    setInput((prev) => prev + value);
  };

  const calculateResult = () => {
    try {
      // Avalia a expressão matemática
      const evalResult = eval(input);
      setResult(evalResult.toString());
    } catch (error) {
      setResult('Error');
    }
  };

  const clearInput = () => {
    setInput('');
    setResult('');
  };
  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        value={input}
        placeholder="0"
        editable={false}
      />
      <Text style={styles.result}>{result}</Text>
      <View style={styles.buttonContainer}>
        {['1', '2', '3', '+'].map((item) => (
          <Button key={item} title={item} onPress={() => handleButtonPress(item)} />
        ))}
      </View>
      <View style={styles.buttonContainer}>
        {['4', '5', '6', '-'].map((item) => (
          <Button key={item} title={item} onPress={() => handleButtonPress(item)} />
        ))}
      </View>
      <View style={styles.buttonContainer}>
        {['7', '8', '9', '*'].map((item) => (
          <Button key={item} title={item} onPress={() => handleButtonPress(item)} />
        ))}
      </View>
      <View style={styles.buttonContainer}>
        <Button title="C" onPress={clearInput} />
        <Button title="0" onPress={() => handleButtonPress('0')} />
        <Button title="=" onPress={calculateResult} />
        <Button title="/" onPress={() => handleButtonPress('/')} />
      </View>
      <View style={styles.buttonContainer}>
        <Button title="." onPress={() => handleButtonPress('.')} />
        <Button title="%" onPress={() => handleButtonPress('/100')} />
      </View>
    </View>
  );
};

const Button = ({ title, onPress }) => (
  <TouchableOpacity style={styles.button} onPress={onPress}>
    <Text style={styles.buttonText}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#303030',
  },
  input: {
    height: 60,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    fontSize: 24,
    textAlign: 'right',
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 12,
  },
  result: {
    fontSize: 32,
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
    backgroundColor: '#fff',
    borderRadius: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  button: {
    flex: 1,
    margin: 5,
    backgroundColor: '#9a21a3',
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    height: 60,
  },
  buttonText: {
    color: '#fff',
    fontSize: 24,
  },
});

export default App;